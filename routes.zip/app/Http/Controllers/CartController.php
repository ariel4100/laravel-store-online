<?php

namespace App\Http\Controllers;

use App\Model\Order;
use App\Model\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    public function __construct()
    {
        if(!Session::has('cart'))
        {
            Session::put('cart',array());
            Session::put('option',array());
        }
    }

    public function index()
    {
        $cart = Session::get('cart');
        $option = Session::get('option');
        $total = $this->total();
        return view('cart.cart', compact('cart','option','total'));
    }

    public function add(Request $request)
    {
        $product = Product::findOrFail($request->id_product);
        $cart = Session::get('cart');
        $opt = Session::get('option');
        $car = $request->only('size','color','quantity','id_product');
        if (!$opt)
        {
            $opt[] = $car;
            Session::put('option',$opt);
            var_dump('sale por aca');
        }
        foreach ($opt as $key=>$item)
        {
            if ($item['size'] == $request->size && $item['color'] == $request->color && $item['id_product'] == $request->id_product)
            {
                //$item['quantity'] += $request->quantity;
                unset($opt[$key]);
                //$opt[$key] = $item;

            }
        }
        $opt[] = $car;

        Session::put('option',$opt);

        $cart[$product->id_product] = $product;

        Session::put('cart',$cart);
        return redirect()->route('cart');
    }
    public function total()
    {
        $opt = Session::get('option');
        $cart = Session::get('cart');
        $total = 0;
        foreach($cart as $item)
        {
            foreach ($opt as $data)
            {
                if ($item->id_product == $data['id_product'])
                {
                    //$sizexqty = $data['quantity'] * count($data['size']);
                    $total +=  $item->price_pro * $data['quantity'];
                }
            }
        }
        return $total;
    }

    public static function cantidad()
    {
        $cart = Session::get('cart');
        $option = Session::get('option');
        $totqty = 0;
        if ($cart)
        {
            foreach ($cart as $item)
            {
                foreach ($option as $data)
                {
                    if ($item->id_product == $data['id_product'])
                    {
                        $totqty += $data['quantity'];
                    }
                }
            }
        }
        return $totqty;
    }


    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $opt = Session::get('option');
        foreach ($opt as $key=>$item)
        {
            if ($item['id_product'] == $product->id_product)
            {
                $item['quantity'] = $request->cantidad;
                $opt[$key] = $item;
            }

        }
        Session::put('option',$opt);
        Session::get('option');
        //return compact('c');
        return redirect()->route('cart');
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $cart = Session::get('cart');
        $opt = Session::get('option');
        foreach ($opt as $key=>$item)
        {
            if ($product->id_product == $item['id_product'])
            {
                unset($opt[$key]);
                //dd($opt);
            }
        }
        unset($cart[$product->id_product]);
        Session::put('cart',$cart);
        Session::put('option',$opt);
        return redirect()->route('cart');
    }

    //Detalle del pedido
    public function orderDetail()
    {
        if(count(Session::get('cart')) <= 0) return redirect()->route('home');
        $cart = Session::get('cart');
        $option = Session::get('option');
        $totqty = $this->cantidad();

        //$pedido= array_merge($option,$cart);
        $total = $this->total();
        return view('cart.order-detail',compact('cart','option','total','totqty'));
    }
    public function saveOrder(Request $request)
    {
        $pedido = new Order();
        $cart = Session::get('cart');
        $option = Session::get('option');

        $pedido->user_id_ord = Auth::user()->id;
        foreach ($cart as $item)
        {
            $pedido->product_id_ord = $item->id_product;

        }
        $pedido->total_ord = $this->total();
        $pedido->save();

        foreach ($option as $data)
        {
            $this->saveOrderItem($data);
        }
        return redirect()->route('productos.get')->with('success','pedido exitosamente rebice su email Gracias :]');
        //return 'jjjjj'. dd($cart);
    }

    private function saveOrderItem($item, $order_id)
    {
        OrderItem::create([
            'quantity' => $item->quantity,
            'price' => $item->price,
            'product_id' => $item->id,
            'order_id' => $order_id
        ]);
    }

}
