<?php $__env->startSection('style'); ?>
    <style>
        .pedido {
            background-color: #f0f0f0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 ml-auto">
            <h2 class="mt-4">NUEVOS CLIENTES</h2>
            <hr>
            <p class="align-items-center">
                Bienvenido a CR Tienda Argentina. Registrate y sé parte de nuestra tienda de modo online.</p>
            <div class="card text-white mb-5" style="background-color: rgba(0,0,0,0.7);">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <!-- Default input -->
                            <div class="form-group col-md-6">
                                <label><?php echo e(__('Nombre')); ?></label>
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <!-- Default input -->
                            <div class="form-group col-md-6">
                                <label><?php echo e(__('Apellido')); ?></label>
                                <input id="surname" type="text" class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" value="<?php echo e(old('surname')); ?>" required autofocus>
                                <?php if($errors->has('surname')): ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('surname')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('E-Mail')); ?></label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group row">
                            <div class="form-group col-md-6">
                                <label><?php echo e(__('Contraseña')); ?></label>
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo e(__('Confirmar Contraseña')); ?></label>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-group col-md-6">
                                <label>Genero: </label>
                                <select name="gender" id="" class="form-control <?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>">
                                    <option value="HOMBRE">Hombre</option>
                                    <option value="MUJER">Mujer</option>
                                </select>
                                <?php if($errors->has('gender')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo e(__('Fecha de Nacimiento: ')); ?></label>
                                <input type="date" class="form-control" name="nationality" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Registrar')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>