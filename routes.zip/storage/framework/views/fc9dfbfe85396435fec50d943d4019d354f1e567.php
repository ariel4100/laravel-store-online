<?php $__env->startSection('style'); ?>
    <style>
        .card:hover {
            background: #e0e0e0 ;
            /*border-top: 1px solid #212121;*/
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid text-dark">
        <!--<div class="row bg-warning text-center  py-4">
            <p class="h1-responsive font-weight-bold mx-auto">Nuestros Best Productos!!!</p>
            <p class="w-responsive mx-auto">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit, error amet numquam iure provident voluptate esse quasi, veritatis totam voluptas nostrum quisquam eum porro a pariatur veniam.</p>
        </div>--->
        <div class="row  mdb-color lighten-1 py-3">
            <div class="col-md-12 mt-5">
                <form action="<?php echo e(route('item')); ?>" method="GET" class="form-row justify-content-center text-white mt-4">
                    <div class="form-group col-md-2">
                        <label for="">Nombre</label>
                        <input type="text" class="form-control mr-3">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="">Descripcion</label>
                        <input type="text" class="form-control mr-3">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="">Categoria</label>
                        <select class="browser-default custom-select" name="categories">
                            <?php $__currentLoopData = $allCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_category); ?>"><?php echo e($item->name_cat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-md-2 mt-3">
                        <button type="submit" class="btn btn-success">Buscar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="container my-5">
        <hr class="bg-info">
        <div class="row">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-lg-0 mb-4">
                    <!-- Card -->
                    <div class="card card-cascade wider card-ecommerce">
                        <div class="view view-cascade overlay">
                            <img src="<?php echo e(asset('uploads/Products/'.$item->image_pro)); ?>" class="card-img-top" alt="sample photo">
                            <a href="<?php echo e(route('detail-item',$item->id_product)); ?>"><div class="mask rgba-white-slight"></div></a>
                        </div>
                        <div class="card-body card-body-cascade text-center">
                            <h4 class="card-title"><strong> <?php echo e($item->name_pro); ?> </strong></h4>
                            <!-- Description -->
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing minima veniam elit.</p>
                            <!-- Card footer -->
                            <div class="card-footer px-1">
                                <span class="float-left font-weight-bold"><b><?php echo e(number_format($item->price_pro,2)); ?>$</b></span>
                                <span class="float-right">
                                    <a href="<?php echo e(route('detail-item',$item->id_product)); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Quick Look"><i class="fas fa-shopping-cart"></i></a>
                                    <a class="active" data-toggle="tooltip" data-placement="top" title="Added to Wishlist"><i class="fa fa-heart text-danger"></i></a>
                                </span>
                            </div>
                        </div>
                        <!-- Card content -->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Grid row -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>