<?php $__env->startSection('content'); ?>
    <section class="container    my-5 pt-3">
        <h2 class="h1-responsive font-weight-bold text-center my-5"><u>¡Carrito de Compras!</u></h2>
        <div class="row">
            <div class="col-md-12">
                <?php if(count($cart)): ?>
                    <table class="table">
                        <thead class="table-dark">
                        <tr>
                            <th>codigo</th>
                            <th>imagen</th>
                            <th>producto</th>
                            <th>variantes</th>
                            <th>eliminar fila</th>
                        </tr>
                        </thead>
                        <tbody>
                        <pre>

                        </pre>
                        <hr>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item['id_product']); ?></th>
                                <td><img class="img-responsive img-thumbnail" src="<?php echo e(asset('uploads/Products/'.$item['image_pro'])); ?>" style="height: 100px; width: 100px" alt=""></td>
                                <td><?php echo e($item->name_pro); ?> <br><?php echo e($item->price_pro); ?> </td>
                                <td>
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Talle</th>
                                            <th>Color</th>
                                            <th>Cantidad</th>
                                            <th>precio</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id_product == $data['id_product']): ?>
                                                <tr>
                                                    <td class="text-center">
                                                       <?php echo e($data['size']); ?>

                                                    </td>
                                                    <td class="text-center">
                                                        <?php echo e($data['color']); ?>

                                                    </td>
                                                    <td style="width: 12rem">
                                                        <form action="<?php echo e(route('cart-update',$item->id_product)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="input-group">
                                                                <input type="number" min="1" name="cantidad" max="150" class="form-control text-center" value="<?php echo e($data['quantity']); ?>">
                                                                <div class="input-group-append">
                                                                    <button type="submit" class="btn  btn-outline-primary btn-sm" > <i class="fa fa-refresh"></i></button>
                                                                </div>
                                                            </div>
                                                        </form>

                                                    </td>
                                                    <td>
                                                        <?php echo e($item['price_pro'] *  $data['quantity']); ?>$
                                                    </td>

                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('cart-destroy',$item->id_product)); ?>" class="btn btn-sm btn-danger">x</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <h3>
                        <div class="alert alert-warning">
                            Total: $ <?php echo e(number_format( $total,0,',','.')); ?> ARG
                        </div>
                    </h3>
                    <div class="my-2">
                        <a href="<?php echo e(route('item')); ?>" class="btn btn-primary btn-lg">seguir comprando</a>
                        <a href="<?php echo e(route('cart-order')); ?>" class="btn btn-success btn-lg">finalizar compra</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-primary text-center">
                        No hay productos en el carrito...
                    </div>
                    <div class="my-2">
                        <a href="<?php echo e(route('item')); ?>" class="btn btn-primary btn-lg">seguir comprando</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        // Update item cart
        $(".btn-update-item").on('click', function(e){
            e.preventDefault();

            var id = $(this).data('id');
            var href = $(this).data('href');
            var quantity = $("#product_" + id).val();

            window.location.href = href + "/" + quantity;
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>