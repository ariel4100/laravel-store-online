<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-md-3">
                <div class="login-box-body">
                    <p class="login-box-msg">Editar Usuario</p>
                    <form method="POST" action="<?php echo e(route('usuarios.update',$user->id)); ?>">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <!-- Default input -->
                            <div class="form-group">
                                <label><?php echo e(__('Nombre')); ?></label>
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name"  value="<?php echo e($user->name); ?>" required autofocus>
                            </div>
                            <!-- Default input -->
                            <div class="form-group">
                                <label><?php echo e(__('Apellido')); ?></label>
                                <input id="surname" type="text" class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname"  value="<?php echo e($user->surname); ?>" required autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('E-Mail')); ?></label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"  value="<?php echo e($user->email); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Contraseña')); ?></label>
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                        </div>

                        <button type="submit" class="btn btn-primary"><?php echo e(__('Registrar')); ?></button>
                    </form>
                </div>
            </div>
            <div class="col-md-9">
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#settings" data-toggle="tab">Agregar mas Datos</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="active tab-pane" id="settings">
                            <form class="box-body">
                                <div class="form-group col-md-4">
                                    <label>Genero: </label>
                                    <select name="gender" id="" class="form-control">
                                        <option value="HOMBRE" <?php echo e($user->gender == 'HOMBRE' ? 'selected' : ''); ?>>Hombre</option>
                                        <option value="MUJER" <?php echo e($user->gender == 'MUJER' ? 'selected' : ''); ?>>Mujer</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label><?php echo e(__('Fecha de Nacimiento: ')); ?></label>
                                    <input type="date" class="form-control" name="nationality" value="<?php echo e($user->nationality); ?>" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Telefono/Cel</label>
                                    <input type="text" class="form-control" name="phone" value="<?php echo e($user->phone); ?>" placeholder="N°Celular">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Pais</label>
                                    <input type="text" class="form-control" name="country" value="<?php echo e($user->country); ?>" placeholder="Pais">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Provincia</label>
                                    <input type="text" class="form-control" name="province" value="<?php echo e($user->province); ?>" placeholder="Ciudad">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Localidad</label>
                                    <input type="text" class="form-control" name="location" value="<?php echo e($user->location); ?>" placeholder="Localidad">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Dirreccion</label>
                                    <input type="text" class="form-control" name="address" value="<?php echo e($user->address); ?>" placeholder="Dirreccion">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Perfil del Cliente</label>
                                    <select name="profile_client" id="" class="form-control">
                                        <option value="MINORISTA" <?php echo e($user->gender == 'MINORISTA' ? 'selected' : ''); ?>>MINORISTA</option>
                                        <option value="MAYORISTA" <?php echo e($user->gender == 'MAYORISTA' ? 'selected' : ''); ?>>MAYORISTA</option>
                                    </select>
                                </div>
                                <!--<div class="form-group col-md-4">
                                    <label>Dirreccion</label>
                                    <input type="text" class="form-control" placeholder="Dirreccion">
                                </div>-->
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-danger">Actualizar Usuario</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>