<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Listado de Clientes</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Clientes</li>
        </ol>
    </section>
    <div class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>44</h3>

                        <p>User Registrations</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-md-8">
                <form action="<?php echo e(route('product_filter')); ?>" method="GET" class="box box-primary">
                    <div class="box-body">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" placeholder="Buscar por Nombre">
                        </div>
                        <div class="form-group">
                            <input type="text" name="category" class="form-control" placeholder="Buscar por Categoria">
                        </div>
                        <div class="form-group">
                            <input type="text" name="status" class="form-control" placeholder="Buscar por Estado">
                        </div>
                        <button type="submit" class="btn btn-success">Buscar</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="box">
                <div class="box-header">
                    <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success">Nuevo usuario</a>
                    <a href="<?php echo e(route('export_user')); ?>" class="btn btn-success">excel</a>
                </div>
                <div class="box-body table-responsive no-padding table-bordered">
                    <table class="table table-bordered table-hover">
                        <thead class="black white-text">
                            <tr class="active">
                                <th scope="col">#</th>
                                <th scope="col">Nombre y Apellido</th>
                                <th scope="col">Email</th>
                                <th scope="col">Genero</th>
                                <th scope="col">Perfil del Cliente</th>
                                <th scope="col">acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->name.' '.$item->surname); ?></td>
                                <td><p class="badge badge-info"><?php echo e($item->email); ?></p></td>
                                <td><?php echo e($item->gender); ?></td>
                                <td><?php echo e($item->profile_client); ?></td>
                                <td>
                                    <a href="<?php echo e(route('usuarios.edit',$item->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('usuarios.destroy',$item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="confirm('Are you sure? You want to delete this?')">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>