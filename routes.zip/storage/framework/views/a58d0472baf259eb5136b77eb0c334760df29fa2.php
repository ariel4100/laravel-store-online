<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Categoria
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Categoria</li>
        </ol>
    </section>
    <div class="content">
        <div class="row">
            <div class="col-md-4 mt-2">
                <div class="box box-primary">
                    <div class="box-body">
                        <form action="<?php echo e(route('category-create')); ?>" method="POST" class="border border-dark p-2">
                            <?php echo method_field('POST'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Nueva Categoria</label>
                                <input type="text" name="name_cat" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-block btn-success">Guardar Categoria</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="box">
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover table-bordered">
                            <tr class="active">
                                <th scope="col">#</th>
                                <th scope="col">Categoria</th>
                                <th scope="col">Estado</th>
                                <th>Acciones</th>
                            </tr>
                            <?php $__currentLoopData = $allCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($item->id_category); ?></th>
                                    <th><?php echo e($item->name_cat); ?></th>
                                    <th></th>
                                    <td>
                                        <form action="<?php echo e(route('category-delete',$item->id_category)); ?>"   method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>